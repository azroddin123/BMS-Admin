import React from 'react'

const GetEnquiry = () => {
  return (
    <div>GetEnquiry</div>
  )
}

export default GetEnquiry