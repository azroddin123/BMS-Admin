export const AppName = "bms";
